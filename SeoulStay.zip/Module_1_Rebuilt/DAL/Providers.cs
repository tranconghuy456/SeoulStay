﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Module_1_Rebuilt.Context;

namespace Module_1_Rebuilt.DAL
{
    public class Providers
    {
        // VARIABLES //
        public SqlConnection Connection { get; set; }
        public string connectionStr { get; set; } = ConfigurationManager.ConnectionStrings["Session1_Rebuilt"].ConnectionString.ToString();

        public bool Connect()
        {
            try
            {
                Connection = new SqlConnection(connectionStr);
                if (Connection.State == ConnectionState.Broken || Connection.State == ConnectionState.Closed)
                {
                    Connection.Open();
                    return true;
                }
                    return false;
            } catch (Exception ex)
            {
                throw;
            }
        }

        public void Disconnect()
        {
            Connection.Dispose();
            Connection.Close();
        }

        //public SqlCommand Command(string queryOrSp, string[] ParametersIn, object[] Values, string[] ParametersOut, string[] ParametersOutType , bool isStored)
        //{
        //    if (Connect())
        //    {
        //        try
        //        {
        //            SqlCommand query = new SqlCommand(queryOrSp, Connection);

        //            if (isStored)
        //            {
        //                query.CommandText = queryOrSp;
        //                query.CommandType = CommandType.StoredProcedure;
        //                query.Connection = Connection;
        //            }

        //            if (ParametersIn != null)
        //                for (int i = 0; i < ParametersIn.Length; i++)
        //                    query.Parameters.AddWithValue(ParametersIn[i], Values[i]);

        //            if (ParametersOut != null && ParametersOut != null)
        //                for (int i = 0; i < ParametersOut.Length; i++)
        //                    query.Parameters.Add(ParametersOut[i], ParametersOutType[i]).Direction = ParameterDirection.Output;
        //            return query;
        //        } catch(Exception ex) { throw; } finally { Disconnect(); }
        //    }
        //}
    }
}