﻿using Module_1_Rebuilt.Context;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Module_1_Rebuilt
{
    public partial class frm_Login : Form
    {
        public frm_Login()
        {
            InitializeComponent();
        }
        


        private void frm_Login_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            userContextBindingSource.EndEdit();
            UserContext user = userContextBindingSource.DataSource as UserContext;
            if (user != null) {
                ValidationContext context = new ValidationContext(user, null, null);
                IList<ValidationResult> results = new List<ValidationResult>();
                if (!Validator.TryValidateObject(user, context, results, true))
                {
                    foreach (ValidationResult result in results) {
                        MessageBox.Show(result.ErrorMessage, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
            }
        }   
    }
}
