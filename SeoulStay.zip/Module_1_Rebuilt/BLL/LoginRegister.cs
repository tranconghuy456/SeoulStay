﻿using Module_1_Rebuilt.DAL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Module_1_Rebuilt.Context;

namespace Module_1_Rebuilt.BLL
{
    class LoginRegister
    {
        Providers providers = new Providers();

        public string[] LoginCheckPoint()
        {
            string[] result = null;
            if (providers.Connect())
            {
                try
                {
                    SqlCommand query = new SqlCommand("[dbo].[Usp_LoginCheckPoint]", providers.Connection);
                    query.CommandType = System.Data.CommandType.StoredProcedure;
                    query.Parameters.AddWithValue("@Username", UserContext.Username);
                    query.Parameters.AddWithValue("@Password", UserContext.Password);
                    query.Parameters.AddWithValue("@UserTypeID", UserContext.UserTypeID);
                    query.Parameters.Add("@RES_MSG", SqlDbType.NChar, 50).Direction = ParameterDirection.Output;
                    query.Parameters.Add("@RES_CODE", SqlDbType.Int).Direction = ParameterDirection.Output;
                    query.ExecuteNonQuery();

                    result = new string[]
                    {
                        query.Parameters["@RES_MSG"].Value.ToString(),
                        query.Parameters["@RES_CODE"].Value.ToString()
                    };
                } catch(Exception ex) {
                    throw;
                } finally
                {
                    providers.Disconnect();
                }
            }
           return result;
        }
    }
}
